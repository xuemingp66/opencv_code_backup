#ifndef __PID_H
#define __PID_H
#include "stm32f1xx_hal.h"

#define LIMIT( x,min,max ) ( (x) < (min)  ? (min) : ( (x) > (max) ? (max) : (x) ) )

struct PID
{
    float KP;
    float KI;
    float KD;
    float error;
    float last_error;
    float pre_error;
    float out;
};

void pid_init(void);
float pid_update(float now,float aim);

#endif
