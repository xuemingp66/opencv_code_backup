#include "stm32f1xx_hal.h"
#include "PID/pid.h"
struct PID pid;

void pid_init(void)
{
	pid.KP = 0.3f;//����
	pid.KI = 0;//����
	pid.KD = 0;//΢��
	pid.error = 0;//���
	pid.last_error = 0;//�ϴ����
	pid.pre_error = 0;//���ϴ����
	pid.out = 0;
}

float pid_update(float now ,float aim)
{
	pid.error = now-aim;
//	pid.derror = pid.error-pid.last_error;
//	pid.ierror += pid.error;
//	pid.ierror = LIMIT(pid.ierror,-3000,3000);
	pid.out = (pid.KP * (pid.error - pid.last_error)) + (pid.KI * pid.error) + (pid.KD * (pid.error - (2 * pid.last_error) + pid.pre_error));
	pid.pre_error = pid.last_error;
	pid.last_error = pid.error;
	return pid.out;
}
