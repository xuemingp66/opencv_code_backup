#ifndef __SERVO_H
#define __SERVO_H

#include "stm32f1xx_hal.h"

void Servo_Init(void);
void Set_pwm(uint32_t pwm1, uint32_t pwm2);

#endif
