#include "stm32f1xx_hal.h"
#include "SERVO/servo.h"
#include "tim.h"

void Servo_Init(void)
{
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);
}

void Set_pwm(uint32_t pwm1, uint32_t pwm2)
{
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, pwm1);
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, pwm2);
}
