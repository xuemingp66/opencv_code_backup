import tkinter as tk
from tkinter.ttk import Progressbar
import cv2
from PIL import Image, ImageTk
import threading
import time

window = tk.Tk()
window.title("First Window")
window.geometry("1000x700")

imageFrame = tk.Frame(window, width=800, height=300)
imageFrame.grid(row=0, column=0, padx=0, pady=0)

lmain = tk.Label(imageFrame)
lmain.grid(row=0, column=0)

cap = cv2.VideoCapture(0)


def cam_loop():
    _, frame = cap.read()
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    img = Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    lmain.imgtk = imgtk
    lmain.configure(image=imgtk)
    #A = A+1
    #lbl = tk.Label(window, text=str(A))
    time.sleep(0.01)
    #lmain.after(1, cam_loop)

btn = tk.Button(window, text="Click Me")
btn.grid(column=2, row=0)

bar = Progressbar(window, length=200, style="black.Horizontal.TProgressbar")
bar["value"] = 70
bar.grid(column=3, row=0)

lbl = tk.Label(window, text="str(A)")
lbl.grid(column=4, row=0)

cam_thread = threading.Thread(target=cam_loop)
cam_thread.setDaemon(True)
cam_thread.start()

window.mainloop()