import cv2
import time

camera = cv2.VideoCapture(0)

start_time = time.time()
time_counter = 0

while True:
    _, frame = camera.read()

    time_counter += 1
    if (time.time() - start_time) != 0:
        cv2.putText(
            frame,
            "FPS: {}".format(
                float("%.1f" % (time_counter / (time.time() - start_time)))
            ),
            (5, 125),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 0, 255),
            2,
        )
        # print("FPS: ", counter / (time.time() - start_time))
    time_counter = 0
    start_time = time.time()

    cv2.imshow("frame", frame)
    # if cv2.waitKey(1) & 0xFF == ord('q'):
    #    break
    cv2.waitKey(1)

camera.release()
cv2.destroyAllWindows()