import cv2
import threading
import time


class mainWindow:
    def videoThread(self):

        start_time = time.time()
        time_counter = 0

        while True:
            ret, frame = self.camera.read()
            print("Video Thread Begin!")

            time_counter += 1
            if (time.time() - start_time) != 0:
                cv2.putText(
                    frame,
                    "FPS: {}".format(
                        float("%.1f" % (time_counter / (time.time() - start_time)))
                    ),
                    (5, 125),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 0, 255),
                    2,
                )
            # print("FPS: ", counter / (time.time() - start_time))
            time_counter = 0
            start_time = time.time()
            cv2.imshow("frame", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        print("Video Thread Finish!")
        self.camera.release()

    def loadVideo(self):
        print("Video Is Opening!!!")

        self.camera = cv2.VideoCapture(0)

        self.thread = threading.Thread(target=self.videoThread)
        self.thread.setDaemon(True)
        self.thread.start()


MW = mainWindow()
MW.loadVideo()
while True:
    print("ttt")
    time.sleep(5)
# MW.videoThread()
