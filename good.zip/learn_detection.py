import jetson.inference
import jetson.utils
import cv2
import threading
import time
import numpy as np
import tkinter as tk  # 导入GUI相关的库
from PIL import Image, ImageTk
from playsound import playsound



# 定义总的窗口标题，大小
window_head = tk.Tk()
window_head.title("盲区检测")
window_head.geometry("482x500")

# 对文字label定义
label_obj = tk.Label(text="OBJ:", font=("Arial", 18))
label_obj.place(x=30, y=350)

# 定义摄像头画面大小，位置
Frame_head = tk.Frame(window_head, width=480, height=270, padx=10, pady=8)
Frame_head.grid(row=0, column=0, padx=0, pady=0)  # 按照元素排列和左上角坐标

# 对画面的label进一步定义
label_head = tk.Label(Frame_head)
label_head.grid(row=0, column=0)

obj = "无"
obj_name = 0

# My_detect_ID
Need_detect_ID = [
    "1",
    "2",
    "3",
    "4",
    "6",
    "8",
]  # person bicycle car motorcyle bus truck

net = jetson.inference.detectNet("ssd-mobilenet-v2", threshold=0.5)
camera = jetson.utils.gstCamera(480, 270, "csi://0")
# display = jetson.utils.glDisplay()

# while display.IsOpen():
def detect_video():
    global obj
    global obj_name

    while True:
        img, width, height = camera.CaptureRGBA(zeroCopy=True)
        jetson.utils.cudaDeviceSynchronize()

        detections = net.Detect(img, width, height)

        npImg = jetson.utils.cudaToNumpy(img, width, height, 4)
        cvImg = cv2.cvtColor(npImg.astype(np.uint8), cv2.COLOR_RGBA2BGR)
        cv2image = cv2.cvtColor(cvImg, cv2.COLOR_BGR2RGBA)
        img = Image.fromarray(cv2image)
        imgtk = ImageTk.PhotoImage(image=img)
        label_head.imgtk = imgtk
        label_head.configure(image=imgtk)
        label_head.image = imgtk

        for detection in detections:
            My_class_ID = str(detection).split()[4]
            if My_class_ID in Need_detect_ID:

                if My_class_ID == "1":
                    obj_name = "person"
                    obj = "行人"


                if My_class_ID == "2":
                    obj_name = "bicycle"
                    obj = "自行车"


                if My_class_ID == "3":
                    obj_name = "car"
                    obj = "汽车"
                  

                if My_class_ID == "4":
                    obj_name = "motorcyle"
                    obj = "摩托车"


                if My_class_ID == "6":
                    obj_name = "bus"
                    obj = "大巴"
                 

                if My_class_ID == "8":
                    obj_name = "truck"
                    obj = "卡车"
                


        label_obj.config(text="请注意，盲区内检测到： " + str(obj))
        #print(obj_list)

def warn_sound():
    global obj
    global obj_name

    while True:
        if obj_name:
            sound_path = "/home/pxm/audio/man/"+str(obj_name)+".wav"
            print(str(sound_path))
            playsound(sound_path)
            obj_name = 0
            obj = "无"
        time.sleep(3)


videoThread = threading.Thread(target=detect_video, args=())
videoThread.start()

soundThread = threading.Thread(target=warn_sound)
soundThread.start()

window_head.mainloop()
